=== Thanh Toán Quét Mã QR - Momo,Zalo Pay,Moca Grab, AirPay ===
Contributors: dangngocbinh
Donate link: http://mecode.pro
Tags: tich hop momo wordpress, tich hop zalopay wordpress, thanh toan quet ma qrcode, plugin moca grab, plugin airpay
Requires at least: 4.6
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tích hợp thanh toán quét mã QR Code Momo, ZaloPay, Grab Moca, AirPay cho Woocommerce

== Description ==

Tích hợp thanh toán quét mã một cách đơn giản nhất

Ưu điểm:
*   Hổ trợ hầu hết nền tảng thanh toán như Momo, ZaloPay, GrabMoca, AirPay
*   Giao dịch nhanh bật app quét là tiền về
*   Không cần có giấy phép kinh doanh, thanh toán hoàn toàn bằng tài khoản cá nhân
*   Không tốn phí giao dịch thanh toán
*   Thanh toán tiện lợi, nhanh chóng
*   Hổ trợ quét mã trên Desktop và cả Mobile

PRO VERSION:
[CHI TIẾT BẢN PRO](http://quet-ma-thanh-toan-pro.mecode.pro/ "xem bản pro")
 

* Xử lý giao dịch hoàn toàn tự động 5 - 10 phút
=> Bạn không cần phải check và xử lý giao dịch bằng tay (áp dụng cho MOMO)
* Tự động điền giá tiền khi quét mã thanh toán
=> Khách hàng đỡ phải nhập giá tiền, sai giá tiền rất tiện (áp dụng cho MOMO)
* Khách hàng có thể quét thanh toán trong Email
=> Gởi Mã QR Code trong email của khách hàng

== Installation ==


1. Cài đặt Plugin như bình thường
2. Kích hoạt Plugin, nhớ cài đặt plugin Woocommerce trước
3. Vào Woocommerce -> Setting -> Payment
4. Chọn các cổng Quét Mã để up hình QR Code là có thể thanh toán được


== Frequently Asked Questions ==
= Tôi cần thêm tính năng cho plugin này thì phải làm sao? =

Bạn vui lòng gởi thông tin vào phần Support để được hổ trợ

= Plugin có xử lý giao dịch tự động không? =


[Có. Xem chi tiết tại đây: ](http://quet-ma-thanh-toan-pro.mecode.pro/ "phiên bản pro")

= Tôi gặp lỗi thì phải làm sao? =

Bạn vui lòng gởi thông tin vào phần Support để được hổ trợ

== Screenshots ==
1. Màn hình cấu hình QR Code
2. Bật tắt cổng thanh toán
3. Màn hình thanh toán trên di động khi người dùng đã tải hình QR Code
4. Màn hình thanh toán khi người dùng chưa tải hình QR Code
5. Màn hình thanh toán trên Desktop
6. Màn hình chọn cổng thanh toán khi đặt hàng

== Changelog ==

= 1.0.0 =
* Hổ trợ Momo, Zalo Pay, Moca, Airpay
= 1.0.1 =
* Cải tiến giao diện thanh toán
= 1.0.2 =
* Thêm nút Tôi Đã Thanh Toán để khách hàng biết đơn hàng sẽ xử lý như thế nào và bao lâu