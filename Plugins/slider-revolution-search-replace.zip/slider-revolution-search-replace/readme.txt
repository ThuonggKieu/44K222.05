=== Slider Revolution Search Replace ===
	
Contributors:dhavalkasvala
Tags:search replace,database,update database urls
Requires at least: 5.0
Tested up to:5.4
Stable up:1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
	
Replace url of old domain to new domain for revolution slider only.

=== Description ===
        
Replace url of old domain to new domain for revolution slider only.

=== installation ===

Visit the https://wordpress.org/plugins/slider-revolution-search-replace/ and download zip and upload it in wordpress plugins directory.

== Screenshots ==

1. The Slider Revolution Search Replace page added to the "Tools" menu