<?php


class mo_disqus
{
    public $color="#2E9FFF";
}