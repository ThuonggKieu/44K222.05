<?php


class mo_spotify
{
    public $color="#1ED760";
}