<?php


class mo_renren
{
    public $color="#063575";
}