<?php


class mo_mailru
{
    public $color="#144786";
}