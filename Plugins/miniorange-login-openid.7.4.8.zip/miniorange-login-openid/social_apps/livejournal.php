<?php


class mo_livejournal
{
    public $color="#306599";
}