<?php


class mo_hubspot
{
    public $color="#314558";
}