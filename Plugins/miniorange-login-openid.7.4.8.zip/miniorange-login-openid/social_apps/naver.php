<?php


class mo_naver
{
    public $color="#1DC800";
}